local config = require "config"
local PalUtility = nil
local isSetup = false
local tracked_pals = {}
local workType = require "worktype"

local function shouldIgnoreWork(workTypeId)
    local workTypeName = workType[workTypeId+1]
    local bool = config.ignore_work_settings[workTypeName]
    print("[TSPR] Pal Current Work Type: " .. workTypeName)
    if bool == nil then return false end
    print("[TSPR] Config setting for this work type is: " .. tostring(bool) .. "\n")
    return bool
end

local function tryUnstuckPal(pal)
    if not pal:IsValid() then print("[TSPR] Skipped unstucking pal as SPR could not get its reference\n") return end
    local params = pal.CharacterParameterComponent
    if not params:IsValid() or params == nil then print("[TSPR] Skipped unstucking pal as SPR could not get its reference\n") return end
    local is_work = params:IsAssignedToAnyWork()
    local is_fight = pal.bIsBattleMode
    local is_sleep = params.IsSleepAction
    local work_type = params.WorkType
    if config.verbose_logging then print("[TSPR] Pal Parameters | Working: " .. tostring(is_work) .. " | Fighting: " .. tostring(is_fight) .. " | Sleeping: " .. tostring(is_sleep) .. "\n") end
    if is_work then
        if config.global_ignore_working ~= true then
            if shouldIgnoreWork(work_type) ~= true then
                print("[TSPR] Skipped unstucking pal as it is working\n") return
            end
        end
    end
    if is_sleep then print("[TSPR] Skipped unstucking pal as it is asleep\n") return end
    if is_fight then print("[TSPR] Skipped unstucking pal as it is in combat\n") return end
    local spawn_location = pal.SpawnLocation_ForServer
    if config.verbose_logging then print("[TSPR] Pal Spawn Location: X: " .. spawn_location.X .. " | Y: " .. spawn_location.Y .. " | Z: " .. spawn_location.Z .. "\n") end

    if PalUtility:IsValid() then
        print("[TSPR] Teleporting stuck pal to spawn location...\n")
        PalUtility:TeleportAroundLoccation(pal, {X=spawn_location.X,Y=spawn_location.Y,Z=(spawn_location.Z+20)}, {W=0.0,X=0.0,Y=0.0,Z=0.0})
    else
        print("[TSPR] Pal Utility Invalid\n")
    end
end

local function unstuckAllPal()
    if config.verbose_logging then print("[TSPR] Attempting to reset all pals\n") end
    local workers = FindAllOf("PalAIActionWorkerChildBase")
    local checkedPals = {}
    if workers then
        for _, worker in ipairs(workers) do
            local pal = worker:GetCharacter()
            if pal:IsValid() then
                local name = pal:GetFullName()
                if checkedPals[name] ~= true then
                    if config.verbose_logging then print("[TSPR] Attempting to reset pal: " .. name .. "\n") end
                    tryUnstuckPal(pal)
                    tracked_pals[name].alerts = 0
                    checkedPals[name] = true
                end
            end
        end
    end
end

local function distance(p1, p2)
    local dx = p2.X - p1.X
    local dy = p2.Y - p1.Y
    local dz = p2.Z - p1.Z
    return math.sqrt(dx*dx + dy*dy + dz*dz)
end

local function palStuckCheck()
    if config.verbose_logging then print("[TSPR] Checking for stuck pals...\n") end
    local workers = FindAllOf("PalAIActionWorkerChildBase")
    if workers then
        local checkedPals = {}
        for _, worker in ipairs(workers) do
            local pal = worker:GetCharacter()
            if pal:IsValid() then
                local name = pal:GetFullName()
                if checkedPals[name] ~= true then
                    if config.verbose_logging then print("[TSPR] Checking Pal: " .. name .. "\n") end
                    local move = pal:GetPalCharacterMovementComponent()
                    if move:IsValid() then
                        local location = move:GetLastUpdateLocation()
                        if config.verbose_logging then print("[TSPR] Pal's Latest Location - X: " .. location.X .. " | Y: " .. location.Y .. " | Z: " .. location.Z .. "\n") end
                        local l_table = {X = location.X, Y = location.Y, Z = location.Z}
                        if tracked_pals[name] == nil then
                            if config.verbose_logging then print("[TSPR] No previous location recorded, stashed location\n") end
                            tracked_pals[name] = { location = l_table, alerts = 0 }
                        else
                            if config.verbose_logging then print("[TSPR] Checking distance moved since last check...\n") end
                            local deltaDist = distance(tracked_pals[name].location, l_table)
                            if deltaDist < config.qualifying_distance then
                                if config.verbose_logging then print("[TSPR] Pal has only moved " .. deltaDist .. " since last check\n") end
                                tracked_pals[name].alerts = tracked_pals[name].alerts + 1
                                if config.verbose_logging then print("[TSPR] Pal has triggered " .. tracked_pals[name].alerts .. " alerts\n") end
                                if tracked_pals[name].alerts >= config.consecutive_triggers_to_teleport then
                                    if config.verbose_logging then print("[TSPR] Attempting to unstuck pal: " .. name .. "\n") end
                                    tryUnstuckPal(pal)
                                end
                            else
                                if config.verbose_logging then print("[TSPR] Pal has moved a sufficient distance since last check, resetting alerts\n") end
                                tracked_pals[name].alerts = 0
                            end
                        end
                        checkedPals[name] = true
                        tracked_pals[name].location = l_table
                    end
                end
            end
        end
    end
end

RegisterHook("/Script/Engine.PlayerController:ServerAcknowledgePossession", function ()
    if (not isSetup) then
        PalUtility = StaticFindObject("/Script/Pal.Default__PalUtility")
        if config.automatically_check_for_stuck_pals then
            local delay = config.loop_interval * 60 * 1000
            LoopAsync(delay, palStuckCheck)
        end
        if config.reset_all_workers_on_cooldown then
            local cd = config.reset_all_worker_timer * 60 * 1000
            LoopAsync(cd, unstuckAllPal)
        end
        isSetup = true
        print("[TSPR] Registered Mod\n")
    end
end)