local _TehSPRConfig = {
    -- Default: True | If true, performs an automatic check for stuck pals based on distance moved since the last loop_interval
    automatically_check_for_stuck_pals = true,

    -- Default: 1 | How often (in MINUTES) the mod checks for stuck pals.
    loop_interval = 1,

    -- Default: 2 | How many times an idle pal needs to be detected by the system in order to be considered stuck and get teleported
    consecutive_triggers_to_teleport = 2,

    -- Default: 400 | How far a pal must have moved to not be considered stuck, in game units. Decreasing this means it will be stricter with the pals it teleports. 
    -- 400 is about corner to corner of one foundation. 
    qualifying_distance = 400,

    -- Default: false | If true, will teleport all worker pals to their spawn location after a set amount of time.
    reset_all_workers_on_cooldown = false,

    -- Default: 20 | The amount of time (in MINUTES) between resetting all workers. If reset_all_workers_on_cooldown is false, does nothing.
    reset_all_worker_timer = 20,

    -- Default: false | If true, teleports pals even if they are working, no matter the task. If false, ignore_work_settings are used to determine whether or not to ignore the work.
    global_ignore_working = false,

    -- Default: false | If true, a pal will be teleported even if they are performing that specific type of task.
    ignore_work_settings = {
    -- Kindling Tasks
        Cooking = false,
        Smelting = false,
        Ignition = false,
    -- Watering Tasks
        Watering = false,
        ExtinguishBurn = false,
    -- Planting Tasks
        Seeding = false,
    -- Generating Electricity Tasks
        GenerateEnergy = false,
    -- Handiwork Tasks
        Architecture = false,
        RepairBuildObject = false,
        ConvertItem = false,
        ProductItem = false,
    -- Gathering Tasks
        FarmHarvest = false,
        HarvestLevelObject = false,
    -- Lumbering Tasks
        ProductResource_Deforest = false,
        ProductResource_Deforest_OnFacility = false,
    -- Mining Tasks
        ProductResource_Mining = false,
        ProductResource_Mining_OnFacility = false,
    -- Medicine Production Tasks
        ProductMedicine = false,
    -- Cooling Tasks
        Cool = false,
    -- Transporting Tasks
        TransportFoodItemInBaseCamp = false,
        TransportDisposableItemInBaseCamp = false,
        TransportItemInBaseCamp = false,
        CollectItemToStorage = false,
        TransportItem = false,
    -- Farming Tasks
        MonsterFarm = false,
    -- General/Unknown
        Defense = false,
        BreedFarm = false,
        Attack = false,
        CollectResource = false,
        CollectResourcePickable = false,
    },

    -- Default: false | If true, enables more verbose logging. Be warned, can get spammy in console.
    verbose_logging = false
}

return _TehSPRConfig