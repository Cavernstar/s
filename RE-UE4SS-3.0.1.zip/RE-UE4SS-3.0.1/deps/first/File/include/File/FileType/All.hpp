#pragma once

#include <File/FileType/WinFile.hpp>
