#include <LuaMadeSimple/LuaObject.hpp>

namespace RC::LuaMadeSimple::Type
{

}
