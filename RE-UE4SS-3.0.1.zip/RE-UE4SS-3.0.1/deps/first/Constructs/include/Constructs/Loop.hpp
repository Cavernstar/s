#ifndef UE4SS_REWRITTEN_LOOP_HPP
#define UE4SS_REWRITTEN_LOOP_HPP

namespace RC
{
    enum class LoopAction
    {
        Continue,
        Break,
    };
} // namespace RC

#endif // UE4SS_REWRITTEN_LOOP_HPP
