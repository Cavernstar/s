# Devlogs

This section will contain a list of development logs that have been written by contributors of UE4SS. These logs are intended to be a way for contributors to share their experiences and knowledge with the community, and to provide a way for the community to understand the development process of UE4SS.

### [DataTables in UE4SS](./devlogs/datatables-in-ue4ss.md) - bitonality (2024-02-07)