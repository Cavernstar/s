# C++ Examples

## Template repository for making UE4SS C++ mods: [UE4SSCPPTemplate](https://github.com/UE4SS-RE/UE4SSCPPTemplate)

### Example repo 1: [kismet-debugger](https://github.com/trumank/kismet-debugger) - trumank