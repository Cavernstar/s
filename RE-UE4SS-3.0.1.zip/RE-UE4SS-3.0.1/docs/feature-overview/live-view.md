# Live Viewer

The Live Viewer is a tool that allows you to search, view, edit & watch the properties of every loaded object making it very powerful for debugging mods or figuring out how values are changed during runtime.

In order to see it, you must make sure that the following configuration settings are set to 1:
- `GuiConsoleEnabled`
- `GuiConsoleVisible`

![live-viewer](https://cdn.discordapp.com/attachments/1109192354595876944/1109192370009940018/image.png)