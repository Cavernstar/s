# C++ API

These are the C++ API functions available in UE4SS, on top of the standard libraries that C++ comes with by default and the reflected functions available in Unreal Engine.

You are expected to have a basic understanding of C++ and Unreal Engine's C++ API before using these functions. 

You may need to read code in the [UEPsuedo](https://github.com/Re-UE4SS/UEPseudo) repository (more specifically, the `include/Unreal` directory) to understand how to use these functions.

For version: **3.0.0**.

Current status: **incomplete**.