function Register()
    return "4053 4883EC30 488BD9 4885D2 7421 458BC8 C74424 28 FFFFFFFF 4533C0 C644242001 E8DA040000 488BC3"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end