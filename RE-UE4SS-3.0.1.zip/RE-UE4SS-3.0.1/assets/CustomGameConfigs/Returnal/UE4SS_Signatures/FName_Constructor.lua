function Register()
    return "48 89 5C 24 08 57 48 83 EC 30 45 33 DB 48 89 54 24 20 41 8B F9 48 8B D9 48 8B C2 48 85 D2 74 25 44 0F B7 12 66 45 85 D2 74 1B 66 0F 1F 44 00 00 48 83 C0 02 41 0F B7 CA 44 0B D9 44 0F B7 10 66 45 85 D2"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end

