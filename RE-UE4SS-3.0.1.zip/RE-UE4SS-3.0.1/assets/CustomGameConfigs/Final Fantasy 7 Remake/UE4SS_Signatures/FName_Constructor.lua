function Register()
    return "4 8/8 9/5 C/2 4/0 8/5 7/4 8/8 3/E C/3 0/4 8/8 B/D 9/4 8/8 9/5 4/2 4/2 0/3 3/C 9"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end