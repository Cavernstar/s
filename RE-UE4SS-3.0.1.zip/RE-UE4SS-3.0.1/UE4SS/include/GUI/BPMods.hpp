#pragma once

namespace RC::GUI::BPMods
{
    auto render() -> void;
}
