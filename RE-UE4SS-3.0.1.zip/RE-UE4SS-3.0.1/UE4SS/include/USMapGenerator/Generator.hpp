#pragma once

namespace RC::OutTheShade
{
    auto generate_usmap() -> void;
}
